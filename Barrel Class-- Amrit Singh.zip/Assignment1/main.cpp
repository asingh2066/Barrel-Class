#include <iostream>
#include "test_barrel.h"
#include "barrel.h"

int main()
{
    // You may add your own test code here for debugging.

    // Uncomment the below line to run the test script.
    test_barrel();

    // Uncomment each of the below test lines individually to test your asserts.
    // Each one should cause your code to *stop* because an assert should fail.
    // If the code does not stop, you are missing an assert or the assert is incorrect.
    test_barrel_assert1();
    // test_barrel_assert2();
    // test_barrel_assert3();
    // test_barrel_assert4();
    return EXIT_SUCCESS;
}
